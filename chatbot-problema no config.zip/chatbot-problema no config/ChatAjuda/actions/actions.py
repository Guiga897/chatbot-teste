from typing import Any, Text, Dict, List
from rasa_sdk import Action, Tracker
from rasa_sdk.executor import CollectingDispatcher
from rasa_sdk.events import SlotSet
import random
import datetime

class ActionConfirmaCadastro(Action):
    def name(self) -> Text:
        return "action_confirma_cadastro"

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
        
        matricula = f"#{random.randint(10000, 99999)}"
        dispatcher.utter_message(
            response="utter_cadastro_confirmado",
            matricula=matricula
        )
        return [SlotSet("matricula_aluno", matricula)]

class ActionRegistrarOcorrencia(Action):
    def name(self) -> Text:
        return "action_registrar_ocorrencia"

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
        
        data_ocorrencia = tracker.get_slot("data_ocorrencia")
        matricula = tracker.get_slot("matricula_aluno")
        
        dispatcher.utter_message(
            text=f"Ocorrência registrada para matrícula {matricula} em {data_ocorrencia}. Protocolo: OC-{datetime.datetime.now().strftime('%Y%m%d%H%M')}"
        )
        return []

class ActionGerarRelatorio(Action):
    def name(self) -> Text:
        return "action_gerar_relatorio"

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
        
        tipo_relatorio = next(tracker.get_latest_entity_values("tipo_relatorio"), None)
        dispatcher.utter_message(
            text=f"Relatório {tipo_relatorio if tipo_relatorio else 'geral'} gerado com sucesso. Disponível por 24h."
        )
        return []

class ActionValidarDocumentos(Action):
    def name(self) -> Text:
        return "action_validar_documentos"

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
        
        documentos = tracker.get_slot("documentos")
        if documentos:
            dispatcher.utter_message(text="Documentos validados com sucesso!")
        else:
            dispatcher.utter_message(text="Atenção: Nenhum documento anexado!")
        
        return [SlotSet("documentos_validados", True if documentos else False)]

class ActionExportarPDF(Action):
    def name(self) -> Text:
        return "action_exportar_pdf"

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
        
        dispatcher.utter_message(
            text="Relatório exportado para PDF: [link temporário]"
        )
        return []